import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { fetchExpenses, fetchRecurring, fetchIncome } from '../lib/dataService';
import { Card } from '../components/Card/Card';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Activity, TrendingUp, DollarSign, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { motion } from 'framer-motion';
import './Overview.css';

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#8b5cf6', '#ef4444', '#14b8a6', '#f43f5e'];

export const Overview = () => {
  const { currentUser } = useAuth();
  
  const [expenses, setExpenses] = useState([]);
  const [recurring, setRecurring] = useState([]);
  const [incomes, setIncomes] = useState([]);

  useEffect(() => {
    if (currentUser) {
      loadData();
    }
  }, [currentUser]);

  const loadData = async () => {
    const fetchedExpenses = await fetchExpenses(currentUser.uid);
    const fetchedRecurring = await fetchRecurring(currentUser.uid);
    const fetchedIncome = await fetchIncome(currentUser.uid);
    setExpenses(fetchedExpenses);
    setRecurring(fetchedRecurring);
    setIncomes(fetchedIncome);
  };

  // Calculate totals for current month
  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  let totalIncome = 0;
  let totalSpending = 0;

  const incomeCategoryMap = {};
  const spendingCategoryMap = {};

  incomes.forEach(inc => {
    const d = new Date(inc.date);
    if (d.getMonth() === currentMonth && d.getFullYear() === currentYear) {
      const amt = parseFloat(inc.amount);
      totalIncome += amt;
      incomeCategoryMap[inc.source] = (incomeCategoryMap[inc.source] || 0) + amt;
    }
  });

  expenses.forEach(exp => {
    const d = new Date(exp.date);
    if (d.getMonth() === currentMonth && d.getFullYear() === currentYear) {
      const amt = parseFloat(exp.amount);
      totalSpending += amt;
      const cat = exp.category || 'uncategorized';
      spendingCategoryMap[cat] = (spendingCategoryMap[cat] || 0) + amt;
    }
  });

  // Add recurring to spending
  recurring.forEach(rec => {
    const amt = parseFloat(rec.amount);
    totalSpending += amt;
    spendingCategoryMap['recurring'] = (spendingCategoryMap['recurring'] || 0) + amt;
  });

  const netCashFlow = totalIncome - totalSpending;

  // Format data for Recharts
  const incomeChartData = Object.keys(incomeCategoryMap)
    .map(key => ({ name: key, value: incomeCategoryMap[key] }))
    .sort((a, b) => b.value - a.value);

  const spendingChartData = Object.keys(spendingCategoryMap)
    .map(key => ({ name: key, value: spendingCategoryMap[key] }))
    .sort((a, b) => b.value - a.value);

  return (
    <div className="overview-container">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="overview-header-cards">
        <Card className="overview-stat-card glass">
          <div className="stat-icon income-bg"><DollarSign size={24} /></div>
          <div>
            <div className="stat-label">Total Income (This Month)</div>
            <div className="stat-value positive">${totalIncome.toFixed(2)}</div>
          </div>
        </Card>
        
        <Card className="overview-stat-card glass">
          <div className="stat-icon spending-bg"><TrendingUp size={24} /></div>
          <div>
            <div className="stat-label">Total Spending (This Month)</div>
            <div className="stat-value negative">${totalSpending.toFixed(2)}</div>
          </div>
        </Card>
        
        <Card className="overview-stat-card glass">
          <div className={`stat-icon ${netCashFlow >= 0 ? 'income-bg' : 'spending-bg'}`}>
            <Activity size={24} />
          </div>
          <div>
            <div className="stat-label">Net Cash Flow</div>
            <div className="stat-value-group">
              <span className={`stat-value ${netCashFlow >= 0 ? 'positive' : 'negative'}`}>
                ${Math.abs(netCashFlow).toFixed(2)}
              </span>
              <span className={`trend-badge ${netCashFlow >= 0 ? 'good' : 'bad'}`}>
                {netCashFlow >= 0 ? <ArrowUpRight size={14}/> : <ArrowDownRight size={14}/>}
              </span>
            </div>
          </div>
        </Card>
      </motion.div>

      <div className="charts-grid">
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1 }}>
          <Card className="chart-card glass">
            <h3>Income Breakdown</h3>
            {incomeChartData.length === 0 ? (
              <div className="empty-chart">No income logged this month.</div>
            ) : (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie data={incomeChartData} innerRadius={60} outerRadius={90} paddingAngle={5} dataKey="value" stroke="none">
                    {incomeChartData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={(value) => `$${value.toFixed(2)}`} contentStyle={{backgroundColor: 'var(--surface-color)', borderRadius: '12px', border: '1px solid var(--border-color)'}} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            )}
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.2 }}>
          <Card className="chart-card glass">
            <h3>Spending Breakdown</h3>
            {spendingChartData.length === 0 ? (
              <div className="empty-chart">No spending logged this month.</div>
            ) : (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie data={spendingChartData} innerRadius={60} outerRadius={90} paddingAngle={5} dataKey="value" stroke="none">
                    {spendingChartData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={(value) => `$${value.toFixed(2)}`} contentStyle={{backgroundColor: 'var(--surface-color)', borderRadius: '12px', border: '1px solid var(--border-color)'}} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            )}
          </Card>
        </motion.div>
      </div>
    </div>
  );
};
