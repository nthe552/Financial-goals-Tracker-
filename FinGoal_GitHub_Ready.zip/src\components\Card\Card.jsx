import React from 'react';
import './Card.css';

export const Card = ({ children, className = '' }) => {
  return (
    <div className={`card glass ${className}`}>
      {children}
    </div>
  );
};
