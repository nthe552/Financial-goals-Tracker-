// Converts a given amount from a specific period to all other periods
export const convertGoalPeriods = (amount, period) => {
  const numAmount = parseFloat(amount);
  if (isNaN(numAmount)) return null;

  let yearly = 0;

  switch (period) {
    case 'daily':
      yearly = numAmount * 365;
      break;
    case 'weekly':
      yearly = numAmount * 52;
      break;
    case 'monthly':
      yearly = numAmount * 12;
      break;
    case 'yearly':
      yearly = numAmount;
      break;
    default:
      return null;
  }

  return {
    daily: (yearly / 365).toFixed(2),
    weekly: (yearly / 52).toFixed(2),
    monthly: (yearly / 12).toFixed(2),
    yearly: yearly.toFixed(2),
  };
};

// Calculates how much is spent against a specific goal
export const calculateProgress = (expenses, goal) => {
  const now = new Date();
  
  // Filter expenses that match the goal category (or all if no category)
  // For simplicity, we just filter by time period right now depending on the goal's tracking period.
  
  let startDate = new Date();
  if (goal.period === 'daily') {
    startDate.setHours(0, 0, 0, 0);
  } else if (goal.period === 'weekly') {
    const day = startDate.getDay() || 7; 
    if (day !== 1) startDate.setHours(-24 * (day - 1)); 
    startDate.setHours(0, 0, 0, 0);
  } else if (goal.period === 'monthly') {
    startDate.setDate(1);
    startDate.setHours(0, 0, 0, 0);
  } else if (goal.period === 'yearly') {
    startDate.setMonth(0, 1);
    startDate.setHours(0, 0, 0, 0);
  }

  const periodExpenses = expenses.filter(exp => {
    const expDate = new Date(exp.date);
    return expDate >= startDate && (!goal.category || exp.category === goal.category);
  });

  const totalSpent = periodExpenses.reduce((sum, exp) => sum + parseFloat(exp.amount), 0);
  
  return {
    totalSpent,
    remaining: Math.max(0, parseFloat(goal.amount) - totalSpent),
    percentage: Math.min(100, (totalSpent / parseFloat(goal.amount)) * 100)
  };
};

// Calculates total summary for the current month
export const calculateMonthlySummary = (expenses, recurringPayments) => {
  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();
  
  // Previous month logic for trend
  let prevMonth = currentMonth - 1;
  let prevYear = currentYear;
  if (prevMonth < 0) {
    prevMonth = 11;
    prevYear -= 1;
  }

  let totalExpensesThisMonth = 0;
  let totalExpensesLastMonth = 0;

  expenses.forEach(exp => {
    const expDate = new Date(exp.date);
    if (expDate.getMonth() === currentMonth && expDate.getFullYear() === currentYear) {
      totalExpensesThisMonth += parseFloat(exp.amount);
    }
    if (expDate.getMonth() === prevMonth && expDate.getFullYear() === prevYear) {
      totalExpensesLastMonth += parseFloat(exp.amount);
    }
  });

  const totalRecurring = recurringPayments.reduce((sum, pay) => sum + parseFloat(pay.amount), 0);
  
  const grandTotal = totalExpensesThisMonth + totalRecurring;
  const prevGrandTotal = totalExpensesLastMonth + totalRecurring; // assume recurring is constant

  // Calculate daily sparkline for current month (up to 30 days)
  const sparklineData = [];
  for (let i = 29; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];
    
    // Find expenses for this specific day
    const dayTotal = expenses
      .filter(exp => exp.date.startsWith(dateStr))
      .reduce((sum, exp) => sum + parseFloat(exp.amount), 0);
      
    sparklineData.push({
      date: d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
      amount: dayTotal
    });
  }

  // Trend vs last month percentage
  let trendPct = 0;
  if (prevGrandTotal > 0) {
    trendPct = ((grandTotal - prevGrandTotal) / prevGrandTotal) * 100;
  } else if (grandTotal > 0) {
    trendPct = 100; // infinite increase
  }

  return {
    expensesTotal: totalExpensesThisMonth,
    recurringTotal: totalRecurring,
    grandTotal: grandTotal,
    trend: trendPct,
    sparkline: sparklineData,
    donutData: [
      { name: 'Variable', value: totalExpensesThisMonth, fill: '#10b981' },
      { name: 'Recurring', value: totalRecurring, fill: '#3b82f6' }
    ]
  };
};

// Calculates historical summary grouped by month for the histogram
export const calculateHistoricalSummary = (expenses, recurringPayments) => {
  const monthlyData = {};

  // Initialize with some default past months for context
  const now = new Date();
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const monthLabel = d.toLocaleString('default', { month: 'short', year: '2-digit' });
    monthlyData[monthKey] = { label: monthLabel, sortKey: monthKey, variable: 0, recurring: 0, total: 0 };
  }

  // Calculate total monthly recurring (assume fixed across all months for simplicity of projection)
  const totalMonthlyRecurring = recurringPayments.reduce((sum, pay) => sum + parseFloat(pay.amount), 0);

  // Group variable expenses by month
  expenses.forEach(exp => {
    const expDate = new Date(exp.date);
    const monthKey = `${expDate.getFullYear()}-${String(expDate.getMonth() + 1).padStart(2, '0')}`;
    const monthLabel = expDate.toLocaleString('default', { month: 'short', year: '2-digit' });

    if (!monthlyData[monthKey]) {
      monthlyData[monthKey] = { label: monthLabel, sortKey: monthKey, variable: 0, recurring: 0, total: 0 };
    }

    monthlyData[monthKey].variable += parseFloat(exp.amount);
  });

  // Apply recurring to all months and calculate total
  Object.keys(monthlyData).forEach(key => {
    monthlyData[key].recurring = totalMonthlyRecurring;
    monthlyData[key].total = monthlyData[key].variable + monthlyData[key].recurring;
  });

  // Sort chronologically and format for chart
  const chartData = Object.values(monthlyData).sort((a, b) => a.sortKey.localeCompare(b.sortKey));

  // Calculate all-time totals
  const allTimeVariable = expenses.reduce((sum, exp) => sum + parseFloat(exp.amount), 0);
  // Accurate all-time recurring is tricky without creation dates for recurring items, 
  // but we can provide the histogram data as the main output.
  
  return {
    chartData,
    allTimeVariable
  };
};
