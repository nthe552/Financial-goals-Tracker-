import { createContext, useContext, useState, useEffect } from 'react';
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged 
} from 'firebase/auth';
import { auth, isFirebaseConfigured } from '../lib/firebase';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Mock functions for when Firebase is not configured
  const mockSignup = (email, password) => {
    const user = { email, uid: 'mock-uid-' + Date.now() };
    localStorage.setItem('mockUser', JSON.stringify(user));
    setCurrentUser(user);
    return Promise.resolve({ user });
  };

  const mockLogin = (email, password) => {
    const user = { email, uid: 'mock-uid-existing' };
    localStorage.setItem('mockUser', JSON.stringify(user));
    setCurrentUser(user);
    return Promise.resolve({ user });
  };

  const mockLogout = () => {
    localStorage.removeItem('mockUser');
    setCurrentUser(null);
    return Promise.resolve();
  };

  useEffect(() => {
    if (isFirebaseConfigured()) {
      const unsubscribe = onAuthStateChanged(auth, (user) => {
        setCurrentUser(user);
        setLoading(false);
      });
      return unsubscribe;
    } else {
      // Mock auth state
      const savedUser = localStorage.getItem('mockUser');
      if (savedUser) {
        setCurrentUser(JSON.parse(savedUser));
      }
      setLoading(false);
    }
  }, []);

  const signup = (email, password) => {
    if (isFirebaseConfigured()) return createUserWithEmailAndPassword(auth, email, password);
    return mockSignup(email, password);
  };

  const login = (email, password) => {
    if (isFirebaseConfigured()) return signInWithEmailAndPassword(auth, email, password);
    return mockLogin(email, password);
  };

  const logout = () => {
    if (isFirebaseConfigured()) return signOut(auth);
    return mockLogout();
  };

  const value = {
    currentUser,
    signup,
    login,
    logout,
    isFirebaseConfigured: isFirebaseConfigured()
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
