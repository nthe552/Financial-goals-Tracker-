import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { fetchGoals, addGoal, deleteGoal, fetchExpenses, addExpense, deleteExpense, fetchRecurring, addRecurring, deleteRecurring } from '../lib/dataService';
import { convertGoalPeriods, calculateProgress, calculateMonthlySummary, calculateHistoricalSummary } from '../utils/calculations';
import { Card } from '../components/Card/Card';
import { Button } from '../components/Button/Button';
import { Input, Select } from '../components/Input/Input';
import { Plus, Trash2, TrendingUp, Target, Repeat, Calendar, ArrowUpRight, ArrowDownRight, Edit2, Check, Search } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, AreaChart, Area } from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import './Spending.css';

export const Spending = () => {
  const { currentUser, isFirebaseConfigured } = useAuth();
  
  const [goals, setGoals] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [recurring, setRecurring] = useState([]);
  
  // UI State
  const [formMode, setFormMode] = useState('expense'); // 'expense', 'goal', 'recurring'
  const [summaryView, setSummaryView] = useState('monthly'); // 'monthly', 'historical'
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedHistoricalMonth, setSelectedHistoricalMonth] = useState('');

  // Quick Add Forms
  const [newGoalName, setNewGoalName] = useState('');
  const [newGoalAmount, setNewGoalAmount] = useState('');
  const [newGoalPeriod, setNewGoalPeriod] = useState('monthly');
  const [newGoalCategory, setNewGoalCategory] = useState('');
  
  const [newExpAmount, setNewExpAmount] = useState('');
  const [newExpCategory, setNewExpCategory] = useState('');
  const [newExpDesc, setNewExpDesc] = useState('');
  const [newExpDate, setNewExpDate] = useState(new Date().toISOString().split('T')[0]);

  const [newRecName, setNewRecName] = useState('');
  const [newRecAmount, setNewRecAmount] = useState('');

  // Inline Edit State
  const [editingExpId, setEditingExpId] = useState(null);
  const [editExpData, setEditExpData] = useState({});

  useEffect(() => {
    if (currentUser) {
      loadData();
    }
  }, [currentUser]);

  const loadData = async () => {
    const fetchedGoals = await fetchGoals(currentUser.uid);
    const fetchedExpenses = await fetchExpenses(currentUser.uid);
    const fetchedRecurring = await fetchRecurring(currentUser.uid);
    setGoals(fetchedGoals);
    setExpenses(fetchedExpenses);
    setRecurring(fetchedRecurring);
  };

  // --- CRUD Handlers ---
  const handleAddGoal = async (e) => {
    e.preventDefault();
    if (!newGoalName || !newGoalAmount) return;
    await addGoal(currentUser.uid, {
      name: newGoalName,
      amount: newGoalAmount,
      period: newGoalPeriod,
      category: newGoalCategory.toLowerCase()
    });
    setNewGoalName(''); setNewGoalAmount(''); setNewGoalCategory('');
    loadData();
  };

  const handleAddExpense = async (e) => {
    e.preventDefault();
    if (!newExpAmount || !newExpDate) return;
    let finalDate = newExpDate;
    if (newExpDate === new Date().toISOString().split('T')[0]) {
      finalDate = new Date().toISOString();
    } else {
      finalDate = new Date(newExpDate).toISOString();
    }
    await addExpense(currentUser.uid, {
      amount: newExpAmount,
      category: newExpCategory.toLowerCase(),
      description: newExpDesc,
      date: finalDate
    });
    setNewExpAmount(''); setNewExpCategory(''); setNewExpDesc('');
    setNewExpDate(new Date().toISOString().split('T')[0]);
    loadData();
  };

  const handleAddRecurring = async (e) => {
    e.preventDefault();
    if (!newRecName || !newRecAmount) return;
    await addRecurring(currentUser.uid, { name: newRecName, amount: newRecAmount });
    setNewRecName(''); setNewRecAmount('');
    loadData();
  };

  const handleDeleteGoal = async (id) => { await deleteGoal(currentUser.uid, id); loadData(); };
  const handleDeleteExpense = async (id) => { await deleteExpense(currentUser.uid, id); loadData(); };
  const handleDeleteRecurring = async (id) => { await deleteRecurring(currentUser.uid, id); loadData(); };

  // --- Inline Edit Handlers ---
  const startEditExp = (exp) => {
    setEditingExpId(exp.id);
    setEditExpData({ ...exp });
  };
  const saveEditExp = async () => {
    // We would ideally have an updateExpense function in dataService, but since we don't, 
    // we delete the old and add the new one with the same date/properties.
    // For local storage demo, this is a bit hacky but works.
    await deleteExpense(currentUser.uid, editingExpId);
    await addExpense(currentUser.uid, editExpData);
    setEditingExpId(null);
    loadData();
  };

  // --- Drag and Drop Logic ---
  const handleDragStart = (e, exp) => {
    e.dataTransfer.setData('application/json', JSON.stringify(exp));
  };
  const handleDropToGoal = async (e, goalCategory) => {
    e.preventDefault();
    if (!goalCategory) return;
    const expData = JSON.parse(e.dataTransfer.getData('application/json'));
    if (expData && expData.category !== goalCategory) {
      await deleteExpense(currentUser.uid, expData.id);
      await addExpense(currentUser.uid, { ...expData, category: goalCategory });
      loadData();
    }
  };

  // --- Data Calculations ---
  const monthlySummary = calculateMonthlySummary(expenses, recurring);
  const historicalSummary = calculateHistoricalSummary(expenses, recurring);

  const sortedExpenses = [...expenses]
    .filter(exp => (exp.description?.toLowerCase() || '').includes(searchQuery.toLowerCase()) || (exp.category?.toLowerCase() || '').includes(searchQuery.toLowerCase()))
    .sort((a, b) => new Date(b.date) - new Date(a.date));

  // Extract unique months for historical view
  const uniqueMonths = [...new Set(expenses.map(e => {
    const d = new Date(e.date);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  }))].sort().reverse();

  useEffect(() => {
    if (uniqueMonths.length > 0 && !selectedHistoricalMonth) {
      setSelectedHistoricalMonth(uniqueMonths[0]);
    }
  }, [uniqueMonths, selectedHistoricalMonth]);

  const historicalMonthExpenses = expenses.filter(e => {
    const d = new Date(e.date);
    const m = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    return m === selectedHistoricalMonth;
  }).sort((a, b) => new Date(b.date) - new Date(a.date));

  // --- Smart Insight ---
  const getSmartInsight = () => {
    if (goals.length > 0) {
      const topGoal = goals[0];
      const prog = calculateProgress(expenses, topGoal);
      if (prog.percentage > 100) return `⚠️ You're trending $${(prog.totalSpent - topGoal.amount).toFixed(0)} over your ${topGoal.name} budget.`;
      if (prog.percentage > 85) return `🔥 High burn rate on ${topGoal.name}. Watch your spending!`;
      return `💡 You're on track for your ${topGoal.name} goal!`;
    }
    return "💡 Track your goals to get smart insights.";
  };

  // Render SVG Circular Progress
  const CircularProgress = ({ percentage }) => {
    const radius = 28;
    const circumference = 2 * Math.PI * radius;
    const cappedPct = Math.min(percentage, 100);
    const offset = circumference - (cappedPct / 100) * circumference;
    const isOver = percentage > 100;
    const color = isOver ? '#ef4444' : '#10b981';

    return (
      <div className="circular-progress-wrapper">
        <svg height="70" width="70" className="circular-svg">
          <circle stroke="#e2e8f0" strokeWidth="6" fill="transparent" r={radius} cx="35" cy="35" />
          <motion.circle 
            stroke={color} strokeWidth="6" fill="transparent" r={radius} cx="35" cy="35"
            strokeDasharray={circumference + ' ' + circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset: offset }}
            transition={{ duration: 1, ease: "easeOut" }}
            style={{ transform: 'rotate(-90deg)', transformOrigin: '50% 50%', strokeLinecap: 'round' }}
          />
        </svg>
        <span className="circular-text" style={{color}}>{Math.round(percentage)}%</span>
      </div>
    );
  };

  return (
    <div className="spending-container">

      {!isFirebaseConfigured && (
        <div className="warning-banner glass">
          Running in Demo Mode. Configure Firebase in src/lib/firebase.js to save data to the cloud.
        </div>
      )}

      {/* Advanced Dashboard Summary */}
      <section className="summary-section">
        <Card className="summary-card glass">
          <div className="summary-header-controls">
            <div className="summary-toggle segmented-control">
              <button className={summaryView === 'monthly' ? 'active' : ''} onClick={() => setSummaryView('monthly')}>Monthly Overview</button>
              <button className={summaryView === 'historical' ? 'active' : ''} onClick={() => setSummaryView('historical')}>Historical Trends</button>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {summaryView === 'monthly' ? (
              <motion.div 
                key="monthly" 
                initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
                className="summary-metrics-grid"
              >
                <div className="metric-box total-spend-box">
                  <span className="summary-label">Total Monthly Spend</span>
                  <div className="grand-total-wrap">
                    <span className="summary-value grand-total">${monthlySummary.grandTotal.toFixed(2)}</span>
                    {monthlySummary.trend !== 0 && (
                      <span className={`trend-badge ${monthlySummary.trend > 0 ? 'bad' : 'good'}`}>
                        {monthlySummary.trend > 0 ? <ArrowUpRight size={14}/> : <ArrowDownRight size={14}/>}
                        {Math.abs(monthlySummary.trend).toFixed(1)}% vs last
                      </span>
                    )}
                  </div>
                  <div className="smart-insight-text">{getSmartInsight()}</div>
                </div>
                
                <div className="metric-box donut-box">
                  <ResponsiveContainer width="100%" height={100}>
                    <PieChart>
                      <Pie data={monthlySummary.donutData} innerRadius={30} outerRadius={45} paddingAngle={5} dataKey="value" stroke="none">
                        {monthlySummary.donutData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.fill} />)}
                      </Pie>
                      <Tooltip formatter={(value) => `$${value}`} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="donut-legend">
                    <div><span className="dot var"></span> Var: ${monthlySummary.expensesTotal.toFixed(0)}</div>
                    <div><span className="dot rec"></span> Rec: ${monthlySummary.recurringTotal.toFixed(0)}</div>
                  </div>
                </div>

                <div className="metric-box spark-box">
                  <span className="summary-label">30-Day Velocity</span>
                  <ResponsiveContainer width="100%" height={80}>
                    <AreaChart data={monthlySummary.sparkline}>
                      <defs>
                        <linearGradient id="colorSpark" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <Area type="monotone" dataKey="amount" stroke="#10b981" fillOpacity={1} fill="url(#colorSpark)" />
                      <Tooltip />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </motion.div>
            ) : (
              <motion.div 
                key="historical"
                initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
                className="summary-historical"
              >
                <div className="historical-header-row">
                  <h3 className="chart-title">Month-by-Month Spending</h3>
                  <Select 
                    value={selectedHistoricalMonth} 
                    onChange={(e) => setSelectedHistoricalMonth(e.target.value)}
                    className="month-selector"
                  >
                    {uniqueMonths.map(m => {
                      const [year, month] = m.split('-');
                      const dateObj = new Date(year, parseInt(month) - 1);
                      return <option key={m} value={m}>{dateObj.toLocaleDateString(undefined, {month: 'long', year: 'numeric'})}</option>;
                    })}
                  </Select>
                </div>
                
                <div className="chart-container" style={{marginBottom: '20px'}}>
                  <ResponsiveContainer width="100%" height={280}>
                    <BarChart data={historicalSummary.chartData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border-color)" />
                      <XAxis dataKey="label" axisLine={false} tickLine={false} tick={{fill: 'var(--text-secondary)', fontSize: 12}} />
                      <YAxis axisLine={false} tickLine={false} tick={{fill: 'var(--text-secondary)', fontSize: 12}} tickFormatter={(value) => `$${value}`} />
                      <Tooltip cursor={{fill: 'rgba(0,0,0,0.05)'}} contentStyle={{backgroundColor: 'var(--surface-color)', borderRadius: '12px', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-md)'}} />
                      <Legend iconType="circle" wrapperStyle={{paddingTop: '10px'}}/>
                      <Bar dataKey="variable" name="Variable Spend" stackId="a" fill="#10b981" radius={[0, 0, 4, 4]} />
                      <Bar dataKey="recurring" name="Recurring Bills" stackId="a" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                      <Line type="monotone" dataKey="total" name="Total Trend" stroke="#f59e0b" strokeWidth={3} dot={{r: 4, fill: '#f59e0b'}} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                <div className="historical-list-container">
                  <h4 style={{marginBottom: '10px', color: 'var(--text-primary)'}}>Transactions in {selectedHistoricalMonth ? new Date(selectedHistoricalMonth.split('-')[0], parseInt(selectedHistoricalMonth.split('-')[1])-1).toLocaleDateString(undefined, {month:'long', year:'numeric'}) : ''}</h4>
                  <div className="expense-table" style={{maxHeight: '250px', overflowY: 'auto'}}>
                    {historicalMonthExpenses.length === 0 ? (
                      <div className="empty-state">No transactions recorded this month.</div>
                    ) : (
                      historicalMonthExpenses.map(exp => (
                        <div key={exp.id} className="expense-table-row">
                          <div className="exp-col-date">
                            <Calendar size={12} />
                            {new Date(exp.date).toLocaleDateString(undefined, {month: 'short', day: 'numeric'})}
                          </div>
                          <div className="exp-col-desc">
                            <strong>{exp.description || 'Unnamed'}</strong>
                            {exp.category && <span className="cat-badge">{exp.category}</span>}
                          </div>
                          <div className="exp-col-actions">
                            <span className="exp-amount">-${parseFloat(exp.amount).toFixed(2)}</span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </Card>
      </section>

      <main className="dashboard-content">
        <div className="dashboard-main-col">
          
          <section>
            <h3 className="section-title"><Target size={20} /> Active Goals</h3>
            <div className="widgets-grid">
              {goals.map(goal => {
                const progress = calculateProgress(expenses, goal);
                const conversions = convertGoalPeriods(goal.amount, goal.period);
                
                return (
                  <motion.div layout key={goal.id} className="goal-card-wrapper" onDragOver={(e) => e.preventDefault()} onDrop={(e) => handleDropToGoal(e, goal.category)}>
                    <Card className="goal-widget glass premium-card">
                      <div className="goal-header">
                        <div className="goal-title-group">
                          <div className={`goal-icon ${progress.percentage > 100 ? 'danger' : ''}`}><Target size={18}/></div>
                          <div>
                            <h4>{goal.name}</h4>
                            <span className="goal-cat-badge">{goal.category}</span>
                          </div>
                        </div>
                        <button onClick={() => handleDeleteGoal(goal.id)} className="delete-btn"><Trash2 size={14} /></button>
                      </div>
                      
                      <div className="goal-body">
                        <CircularProgress percentage={progress.percentage} />
                        <div className="goal-stats">
                          <div className="goal-main-amount">
                            <span className="amount">${goal.amount}</span><span className="period">/{goal.period.charAt(0)}</span>
                          </div>
                          <div className="spent-left">
                            <span className="spent">${progress.totalSpent.toFixed(0)} spent</span>
                            <span className={progress.percentage > 100 ? 'danger-text' : 'left'}>${Math.abs(progress.remaining).toFixed(0)} {progress.percentage > 100 ? 'over' : 'left'}</span>
                          </div>
                        </div>
                      </div>

                      {conversions && (
                        <div className="smart-breakdown premium-breakdown">
                          {goal.period !== 'daily' && <div>Day <strong>${conversions.daily}</strong></div>}
                          {goal.period !== 'weekly' && <div>Wk <strong>${conversions.weekly}</strong></div>}
                          {goal.period !== 'monthly' && <div>Mo <strong>${conversions.monthly}</strong></div>}
                        </div>
                      )}
                    </Card>
                  </motion.div>
                );
              })}
              {goals.length === 0 && <div className="empty-state glass">No goals created yet. Create your first goal to get smart insights!</div>}
            </div>
          </section>

          <div className="lists-grid">
            <section>
              <div className="section-header-row">
                <h3 className="section-title"><TrendingUp size={20} /> Expenses</h3>
                <div className="search-bar">
                  <Search size={14} className="search-icon" />
                  <input type="text" placeholder="Search..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
                </div>
              </div>
              <Card className="expenses-list premium-list glass">
                {sortedExpenses.length === 0 ? (
                  <div className="empty-state">No expenses match.</div>
                ) : (
                  <div className="expense-table">
                    <div className="expense-table-header">
                      <span className="w-date">Date</span>
                      <span className="w-desc">Description</span>
                      <span className="w-amt">Amount</span>
                    </div>
                    <AnimatePresence>
                      {sortedExpenses.map(exp => (
                        <motion.div 
                          initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, scale: 0.9 }}
                          key={exp.id} className="expense-table-row draggable-row" 
                          draggable 
                          onDragStart={(e) => handleDragStart(e, exp)}
                        >
                          {editingExpId === exp.id ? (
                            <div className="inline-edit-form">
                              <input type="date" value={editExpData.date.split('T')[0]} onChange={e => setEditExpData({...editExpData, date: e.target.value})} className="edit-input w-date" />
                              <input type="text" value={editExpData.description} onChange={e => setEditExpData({...editExpData, description: e.target.value})} className="edit-input w-desc" />
                              <input type="number" value={editExpData.amount} onChange={e => setEditExpData({...editExpData, amount: e.target.value})} className="edit-input w-amt-small" />
                              <button onClick={saveEditExp} className="save-btn"><Check size={16}/></button>
                            </div>
                          ) : (
                            <>
                              <div className="exp-col-date">
                                <Calendar size={12} />
                                {new Date(exp.date).toLocaleDateString(undefined, {month: 'short', day: 'numeric'})}
                              </div>
                              <div className="exp-col-desc">
                                <strong>{exp.description || 'Unnamed'}</strong>
                                {exp.category && <span className="cat-badge">{exp.category}</span>}
                              </div>
                              <div className="exp-col-actions">
                                <span className="exp-amount">-${parseFloat(exp.amount).toFixed(2)}</span>
                                <button onClick={() => startEditExp(exp)} className="icon-btn edit-icon"><Edit2 size={14} /></button>
                                <button onClick={() => handleDeleteExpense(exp.id)} className="icon-btn delete-icon"><Trash2 size={14} /></button>
                              </div>
                            </>
                          )}
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                )}
              </Card>
            </section>

            <section>
              <h3 className="section-title"><Repeat size={20} /> Recurring Payments</h3>
              <Card className="expenses-list premium-list glass">
                {recurring.length === 0 ? (
                  <div className="empty-state">No recurring payments.</div>
                ) : (
                  <div className="expense-table">
                    <AnimatePresence>
                      {recurring.map(rec => (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} key={rec.id} className="expense-table-row">
                          <div className="exp-col-desc">
                            <Repeat size={12} className="inline-icon text-blue" />
                            <strong>{rec.name}</strong>
                            <span className="cat-badge blue">Monthly</span>
                          </div>
                          <div className="exp-col-actions">
                            <span className="exp-amount">-${parseFloat(rec.amount).toFixed(2)}</span>
                            <button onClick={() => handleDeleteRecurring(rec.id)} className="icon-btn delete-icon"><Trash2 size={14} /></button>
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                )}
              </Card>
            </section>
          </div>
        </div>

        {/* Right Column: Unified Quick Add Form */}
        <div className="dashboard-side-col">
          <Card className="form-card quick-add-card glass">
            <div className="quick-add-header">
              <h3>Quick Add</h3>
            </div>
            
            <div className="segmented-control tabs">
              <button className={formMode === 'expense' ? 'active' : ''} onClick={() => setFormMode('expense')}>Expense</button>
              <button className={formMode === 'goal' ? 'active' : ''} onClick={() => setFormMode('goal')}>Goal</button>
              <button className={formMode === 'recurring' ? 'active' : ''} onClick={() => setFormMode('recurring')}>Recurring</button>
            </div>

            <AnimatePresence mode="wait">
              {formMode === 'expense' && (
                <motion.form initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} onSubmit={handleAddExpense} className="animated-form">
                  <div className="form-row">
                    <Input label="Amount ($)" type="number" step="0.01" required value={newExpAmount} onChange={e => setNewExpAmount(e.target.value)} placeholder="0.00" />
                    <Input label="Date" type="date" required value={newExpDate} onChange={e => setNewExpDate(e.target.value)} />
                  </div>
                  <Input label="Description" type="text" required value={newExpDesc} onChange={e => setNewExpDesc(e.target.value)} placeholder="e.g. Groceries" />
                  <Input label="Category (Matches Goal)" type="text" value={newExpCategory} onChange={e => setNewExpCategory(e.target.value)} placeholder="e.g. food" />
                  <Button type="submit" className="w-full" variant="primary"><Plus size={16} /> Record Expense</Button>
                </motion.form>
              )}

              {formMode === 'goal' && (
                <motion.form initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} onSubmit={handleAddGoal} className="animated-form">
                  <Input label="Goal Name" type="text" required value={newGoalName} onChange={e => setNewGoalName(e.target.value)} placeholder="e.g. Food Budget" />
                  <div className="form-row">
                    <Input label="Amount ($)" type="number" step="0.01" required value={newGoalAmount} onChange={e => setNewGoalAmount(e.target.value)} placeholder="200" />
                    <Select label="Period" value={newGoalPeriod} onChange={e => setNewGoalPeriod(e.target.value)}>
                      <option value="daily">Daily</option>
                      <option value="weekly">Weekly</option>
                      <option value="monthly">Monthly</option>
                      <option value="yearly">Yearly</option>
                    </Select>
                  </div>
                  <Input label="Category to Track" type="text" value={newGoalCategory} onChange={e => setNewGoalCategory(e.target.value)} placeholder="e.g. food" />
                  <Button type="submit" variant="primary" className="w-full"><Target size={16} /> Create Goal</Button>
                </motion.form>
              )}

              {formMode === 'recurring' && (
                <motion.form initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} onSubmit={handleAddRecurring} className="animated-form">
                  <Input label="Subscription / Bill Name" type="text" required value={newRecName} onChange={e => setNewRecName(e.target.value)} placeholder="e.g. Netflix" />
                  <Input label="Monthly Amount ($)" type="number" step="0.01" required value={newRecAmount} onChange={e => setNewRecAmount(e.target.value)} placeholder="15.00" />
                  <Button type="submit" className="w-full" variant="primary"><Repeat size={16} /> Add Subscription</Button>
                </motion.form>
              )}
            </AnimatePresence>
          </Card>
        </div>
      </main>
    </div>
  );
};
