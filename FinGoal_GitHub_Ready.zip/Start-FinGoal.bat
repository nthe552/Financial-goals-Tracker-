@echo off
echo =========================================
echo       Starting FinGoal Application
echo =========================================

REM Check if dependencies need to be installed
IF NOT EXIST "node_modules\" (
    echo [1/2] Installing dependencies for the first time. This may take a minute...
    call npm install
) ELSE (
    echo [1/2] Dependencies found.
)

echo [2/2] Launching the Electron App...
call npm run electron:dev

pause
