@echo off
setlocal
echo =========================================
echo       Starting FinGoal Application
echo =========================================

REM Check if node exists in PATH
WHERE npm >nul 2>nul
IF %ERRORLEVEL% NEQ 0 (
    echo [!] npm is not recognized!
    echo [!] Downloading Portable Node.js to run the app...
    IF NOT EXIST "%~dp0node-portable" (
        mkdir "%~dp0node-portable"
        echo Downloading Node.js...
        curl -L "https://nodejs.org/dist/v20.11.1/node-v20.11.1-win-x64.zip" -o "%~dp0node.zip"
        echo Extracting Node.js ^(this may take a minute^)...
        powershell -command "Expand-Archive -Force '%~dp0node.zip' '%~dp0node-portable'"
        del "%~dp0node.zip"
    )
    set "PATH=%~dp0node-portable\node-v20.11.1-win-x64;%PATH%"
)

IF NOT EXIST "%~dp0node_modules\" (
    echo [1/2] Installing dependencies for the first time. This may take a minute...
    call npm install --no-audit --no-fund
) ELSE (
    echo [1/2] Dependencies found.
)

echo [2/2] Launching the Electron App...
call npm run electron:dev

pause
