import React from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { Activity, LayoutDashboard, TrendingUp, DollarSign, LogOut, Sun, Moon, Download, Upload, FileJson } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { Button } from '../Button/Button';
import './Layout.css';

export const Layout = () => {
  const { currentUser, logout, isFirebaseConfigured } = useAuth();
  const { isDarkMode, toggleTheme } = useTheme();

  // --- JSON Backup / Restore ---
  const exportBackupJSON = () => {
    const backup = {
      goals: JSON.parse(localStorage.getItem(`goals_${currentUser.uid}`) || '[]'),
      expenses: JSON.parse(localStorage.getItem(`expenses_${currentUser.uid}`) || '[]'),
      recurring: JSON.parse(localStorage.getItem(`recurring_${currentUser.uid}`) || '[]'),
      income: JSON.parse(localStorage.getItem(`income_${currentUser.uid}`) || '[]'),
      expectedIncome: JSON.parse(localStorage.getItem(`expectedIncome_${currentUser.uid}`) || '[]'),
    };
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backup));
    const link = document.createElement("a");
    link.setAttribute("href", dataStr);
    link.setAttribute("download", `fingoal_backup.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const importBackupJSON = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const backup = JSON.parse(event.target.result);
        if (backup.goals) localStorage.setItem(`goals_${currentUser.uid}`, JSON.stringify(backup.goals));
        if (backup.expenses) localStorage.setItem(`expenses_${currentUser.uid}`, JSON.stringify(backup.expenses));
        if (backup.recurring) localStorage.setItem(`recurring_${currentUser.uid}`, JSON.stringify(backup.recurring));
        if (backup.income) localStorage.setItem(`income_${currentUser.uid}`, JSON.stringify(backup.income));
        if (backup.expectedIncome) localStorage.setItem(`expectedIncome_${currentUser.uid}`, JSON.stringify(backup.expectedIncome));
        window.location.reload();
      } catch (err) {
        alert("Failed to parse backup file.");
      }
    };
    reader.readAsText(file);
    e.target.value = null; // reset input
  };

  return (
    <div className="layout-container">
      {/* Sidebar Navigation */}
      <aside className="sidebar glass">
        <div className="brand sidebar-brand">
          <Activity className="brand-icon" size={28} />
          <h2>FinGoal</h2>
        </div>

        <nav className="sidebar-nav">
          <NavLink to="/overview" className={({isActive}) => `nav-item ${isActive ? 'active' : ''}`}>
            <LayoutDashboard size={20} />
            <span>Overview</span>
          </NavLink>
          <NavLink to="/spending" className={({isActive}) => `nav-item ${isActive ? 'active' : ''}`}>
            <TrendingUp size={20} />
            <span>Spending</span>
          </NavLink>
          <NavLink to="/income" className={({isActive}) => `nav-item ${isActive ? 'active' : ''}`}>
            <DollarSign size={20} />
            <span>Income</span>
          </NavLink>
        </nav>

        <div className="sidebar-footer">
          <Button variant="outline" className="w-full text-left" onClick={logout}>
            <LogOut size={16} className="mr-2" /> Logout
          </Button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="main-content">
        <header className="top-header glass">
          <div className="header-left">
            {!isFirebaseConfigured && (
              <span className="demo-badge">Demo Mode Active</span>
            )}
          </div>
          <div className="user-controls">
            {!isFirebaseConfigured && (
              <>
                <Button variant="outline" className="icon-btn" onClick={exportBackupJSON} title="Backup Data (JSON)">
                  <FileJson size={18} />
                </Button>
                <label className="icon-btn file-upload-btn" title="Import Data (JSON)">
                  <Upload size={18} />
                  <input type="file" accept=".json" onChange={importBackupJSON} style={{ display: 'none' }} />
                </label>
              </>
            )}
            <Button variant="outline" className="icon-btn" onClick={toggleTheme} title="Toggle Theme">
              {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
            </Button>
            <span className="user-email">{currentUser.email}</span>
          </div>
        </header>

        <div className="page-content">
          <Outlet />
        </div>
      </main>
    </div>
  );
};
