import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { fetchExpectedIncome, addExpectedIncome, deleteExpectedIncome, fetchIncome, addIncome, deleteIncome } from '../lib/dataService';
import { Card } from '../components/Card/Card';
import { Button } from '../components/Button/Button';
import { Input, Select } from '../components/Input/Input';
import { Plus, Trash2, DollarSign, Calendar, Edit2, Check, Search, Target } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import './Income.css';

export const Income = () => {
  const { currentUser } = useAuth();
  
  const [expectedIncome, setExpectedIncome] = useState([]);
  const [incomes, setIncomes] = useState([]);
  
  // UI State
  const [formMode, setFormMode] = useState('paycheck'); // 'paycheck', 'expected'
  const [searchQuery, setSearchQuery] = useState('');

  // Quick Add Forms
  const [newExpIncName, setNewExpIncName] = useState('');
  const [newExpIncAmount, setNewExpIncAmount] = useState('');
  const [newExpIncPeriod, setNewExpIncPeriod] = useState('monthly');
  
  const [newIncAmount, setNewIncAmount] = useState('');
  const [newIncSource, setNewIncSource] = useState('paycheck');
  const [newIncDesc, setNewIncDesc] = useState('');
  const [newIncDate, setNewIncDate] = useState(new Date().toISOString().split('T')[0]);

  // Inline Edit State
  const [editingIncId, setEditingIncId] = useState(null);
  const [editIncData, setEditIncData] = useState({});

  useEffect(() => {
    if (currentUser) loadData();
  }, [currentUser]);

  const loadData = async () => {
    const fetchedExpected = await fetchExpectedIncome(currentUser.uid);
    const fetchedIncome = await fetchIncome(currentUser.uid);
    setExpectedIncome(fetchedExpected);
    setIncomes(fetchedIncome);
  };

  const handleAddExpected = async (e) => {
    e.preventDefault();
    if (!newExpIncName || !newExpIncAmount) return;
    await addExpectedIncome(currentUser.uid, {
      name: newExpIncName,
      amount: newExpIncAmount,
      period: newExpIncPeriod
    });
    setNewExpIncName(''); setNewExpIncAmount('');
    loadData();
  };

  const handleAddIncome = async (e) => {
    e.preventDefault();
    if (!newIncAmount || !newIncDate) return;
    let finalDate = newIncDate;
    if (newIncDate === new Date().toISOString().split('T')[0]) {
      finalDate = new Date().toISOString();
    } else {
      finalDate = new Date(newIncDate).toISOString();
    }
    await addIncome(currentUser.uid, {
      amount: newIncAmount,
      source: newIncSource,
      description: newIncDesc,
      date: finalDate
    });
    setNewIncAmount(''); setNewIncSource('paycheck'); setNewIncDesc('');
    setNewIncDate(new Date().toISOString().split('T')[0]);
    loadData();
  };

  const handleDeleteExpected = async (id) => { await deleteExpectedIncome(currentUser.uid, id); loadData(); };
  const handleDeleteIncome = async (id) => { await deleteIncome(currentUser.uid, id); loadData(); };

  const startEditInc = (inc) => {
    setEditingIncId(inc.id);
    setEditIncData({ ...inc });
  };
  
  const saveEditInc = async () => {
    await deleteIncome(currentUser.uid, editingIncId);
    await addIncome(currentUser.uid, editIncData);
    setEditingIncId(null);
    loadData();
  };

  const sortedIncomes = [...incomes]
    .filter(inc => (inc.description?.toLowerCase() || '').includes(searchQuery.toLowerCase()) || (inc.source?.toLowerCase() || '').includes(searchQuery.toLowerCase()))
    .sort((a, b) => new Date(b.date) - new Date(a.date));

  // Progress logic for expected income
  const calculateIncomeProgress = (expectedGoal) => {
    const now = new Date();
    // Assuming monthly period for simplification in this view
    const currentMonthIncomes = incomes.filter(inc => {
      const d = new Date(inc.date);
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    });
    const totalEarned = currentMonthIncomes.reduce((sum, inc) => sum + parseFloat(inc.amount), 0);
    const target = parseFloat(expectedGoal.amount);
    const percentage = target > 0 ? (totalEarned / target) * 100 : 0;
    return { totalEarned, target, percentage };
  };

  const CircularProgress = ({ percentage }) => {
    const radius = 28;
    const circumference = 2 * Math.PI * radius;
    const cappedPct = Math.min(percentage, 100);
    const offset = circumference - (cappedPct / 100) * circumference;
    const color = percentage >= 100 ? '#10b981' : '#3b82f6'; // Green if hit target, Blue if tracking

    return (
      <div className="circular-progress-wrapper">
        <svg height="70" width="70" className="circular-svg">
          <circle stroke="#e2e8f0" strokeWidth="6" fill="transparent" r={radius} cx="35" cy="35" />
          <motion.circle 
            stroke={color} strokeWidth="6" fill="transparent" r={radius} cx="35" cy="35"
            strokeDasharray={circumference + ' ' + circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset: offset }}
            transition={{ duration: 1, ease: "easeOut" }}
            style={{ transform: 'rotate(-90deg)', transformOrigin: '50% 50%', strokeLinecap: 'round' }}
          />
        </svg>
        <span className="circular-text" style={{color}}>{Math.round(percentage)}%</span>
      </div>
    );
  };

  return (
    <div className="income-container">
      <main className="dashboard-content">
        <div className="dashboard-main-col">
          
          <section>
            <h3 className="section-title"><Target size={20} /> Expected Monthly Earnings</h3>
            <div className="widgets-grid">
              {expectedIncome.map(goal => {
                const progress = calculateIncomeProgress(goal);
                
                return (
                  <motion.div layout key={goal.id}>
                    <Card className="goal-widget glass premium-card">
                      <div className="goal-header">
                        <div className="goal-title-group">
                          <div className={`goal-icon income-icon`}><DollarSign size={18}/></div>
                          <div>
                            <h4>{goal.name}</h4>
                            <span className="goal-cat-badge blue">{goal.period}</span>
                          </div>
                        </div>
                        <button onClick={() => handleDeleteExpected(goal.id)} className="delete-btn"><Trash2 size={14} /></button>
                      </div>
                      
                      <div className="goal-body">
                        <CircularProgress percentage={progress.percentage} />
                        <div className="goal-stats">
                          <div className="goal-main-amount">
                            <span className="amount">${goal.amount}</span><span className="period">/{goal.period.charAt(0)}</span>
                          </div>
                          <div className="spent-left">
                            <span className="spent">${progress.totalEarned.toFixed(0)} earned</span>
                            <span className="left" style={{color: progress.percentage >= 100 ? '#10b981' : '#64748b'}}>
                              ${Math.max(0, progress.target - progress.totalEarned).toFixed(0)} to go
                            </span>
                          </div>
                        </div>
                      </div>
                    </Card>
                  </motion.div>
                );
              })}
              {expectedIncome.length === 0 && <div className="empty-state glass">No expected earnings set. Track your salary or expected side-hustle income here!</div>}
            </div>
          </section>

          <div className="lists-grid">
            <section>
              <div className="section-header-row">
                <h3 className="section-title"><DollarSign size={20} /> Income History</h3>
                <div className="search-bar">
                  <Search size={14} className="search-icon" />
                  <input type="text" placeholder="Search deposits..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
                </div>
              </div>
              <Card className="expenses-list premium-list glass">
                {sortedIncomes.length === 0 ? (
                  <div className="empty-state">No income logged yet.</div>
                ) : (
                  <div className="expense-table">
                    <div className="expense-table-header">
                      <span className="w-date">Date</span>
                      <span className="w-desc">Description</span>
                      <span className="w-amt">Amount</span>
                    </div>
                    <AnimatePresence>
                      {sortedIncomes.map(inc => (
                        <motion.div 
                          initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, scale: 0.9 }}
                          key={inc.id} className="expense-table-row"
                        >
                          {editingIncId === inc.id ? (
                            <div className="inline-edit-form">
                              <input type="date" value={editIncData.date.split('T')[0]} onChange={e => setEditIncData({...editIncData, date: e.target.value})} className="edit-input w-date" />
                              <input type="text" value={editIncData.description} onChange={e => setEditIncData({...editIncData, description: e.target.value})} className="edit-input w-desc" />
                              <input type="number" value={editIncData.amount} onChange={e => setEditIncData({...editIncData, amount: e.target.value})} className="edit-input w-amt-small" />
                              <button onClick={saveEditInc} className="save-btn"><Check size={16}/></button>
                            </div>
                          ) : (
                            <>
                              <div className="exp-col-date">
                                <Calendar size={12} />
                                {new Date(inc.date).toLocaleDateString(undefined, {month: 'short', day: 'numeric'})}
                              </div>
                              <div className="exp-col-desc">
                                <strong>{inc.description || 'Unnamed'}</strong>
                                <span className={`cat-badge source-${inc.source}`}>{inc.source}</span>
                              </div>
                              <div className="exp-col-actions">
                                <span className="exp-amount positive">+${parseFloat(inc.amount).toFixed(2)}</span>
                                <button onClick={() => startEditInc(inc)} className="icon-btn edit-icon"><Edit2 size={14} /></button>
                                <button onClick={() => handleDeleteIncome(inc.id)} className="icon-btn delete-icon"><Trash2 size={14} /></button>
                              </div>
                            </>
                          )}
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                )}
              </Card>
            </section>
          </div>
        </div>

        {/* Right Column: Unified Quick Add Form */}
        <div className="dashboard-side-col">
          <Card className="form-card quick-add-card glass">
            <div className="quick-add-header">
              <h3>Log Income</h3>
            </div>
            
            <div className="segmented-control tabs">
              <button className={formMode === 'paycheck' ? 'active' : ''} onClick={() => setFormMode('paycheck')}>Deposit</button>
              <button className={formMode === 'expected' ? 'active' : ''} onClick={() => setFormMode('expected')}>Expected</button>
            </div>

            <AnimatePresence mode="wait">
              {formMode === 'paycheck' && (
                <motion.form initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} onSubmit={handleAddIncome} className="animated-form">
                  <div className="form-row">
                    <Input label="Amount ($)" type="number" step="0.01" required value={newIncAmount} onChange={e => setNewIncAmount(e.target.value)} placeholder="0.00" />
                    <Input label="Date" type="date" required value={newIncDate} onChange={e => setNewIncDate(e.target.value)} />
                  </div>
                  <Input label="Description" type="text" required value={newIncDesc} onChange={e => setNewIncDesc(e.target.value)} placeholder="e.g. Acme Corp Salary" />
                  <Select label="Source" value={newIncSource} onChange={e => setNewIncSource(e.target.value)}>
                    <option value="paycheck">Paycheck</option>
                    <option value="bonus">Bonus</option>
                    <option value="investment">Investment</option>
                    <option value="other">Other</option>
                  </Select>
                  <Button type="submit" className="w-full" variant="primary"><Plus size={16} /> Record Deposit</Button>
                </motion.form>
              )}

              {formMode === 'expected' && (
                <motion.form initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} onSubmit={handleAddExpected} className="animated-form">
                  <Input label="Income Stream Name" type="text" required value={newExpIncName} onChange={e => setNewExpIncName(e.target.value)} placeholder="e.g. Salary" />
                  <div className="form-row">
                    <Input label="Expected Amount ($)" type="number" step="0.01" required value={newExpIncAmount} onChange={e => setNewExpIncAmount(e.target.value)} placeholder="5000" />
                    <Select label="Period" value={newExpIncPeriod} onChange={e => setNewExpIncPeriod(e.target.value)}>
                      <option value="monthly">Monthly</option>
                      <option value="yearly">Yearly</option>
                    </Select>
                  </div>
                  <Button type="submit" variant="primary" className="w-full"><Target size={16} /> Set Expectation</Button>
                </motion.form>
              )}
            </AnimatePresence>
          </Card>
        </div>
      </main>
    </div>
  );
};
